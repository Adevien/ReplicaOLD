using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LiteNetLib;
using LiteNetLib.Utils;
using UnityEngine.SceneManagement;

public class HexConnection : MonoBehaviour {

    NetPacketProcessor _Processor = new NetPacketProcessor();

    EventBasedNetListener _Events = new EventBasedNetListener();

    NetPeer Peer;

    NetManager _Manager;

    private void Awake() {
        _Manager = new NetManager(_Events);

        _Events.PeerConnectedEvent += (peer) => Debug.Log($"We connected to server {peer.EndPoint}");
        _Events.PeerDisconnectedEvent += (peer, di) => Debug.Log($"We disconnected from server {peer.EndPoint}. Reason {di.Reason}");
        _Events.NetworkReceiveEvent += (peer, reader, channel, deliveryMethod) => _Processor.ReadAllPackets(reader);

        RegisterMessages();

        if (_Manager.Start()) {
            Peer = _Manager.Connect("127.0.0.1", 2500, "hex_arena");
            print("HEX_CONNECTION: Started on port (2500).");
        } else print("HEX_CONNECTION: Failed to start manager.");
        accumulator = TickAccumulator.Initialize();
    }

    public TickAccumulator accumulator;

    public int TickRate = 32;

    public float DeltaTime {
        get => 1.0f / TickRate;
    }

    public int MaxTicksBehind = 4;
    public float MaxPredictedTime = 1f;


    public void Update() {

        _currentLocalTime = Time.time;
        if (_Manager.IsRunning) {
            _Manager.PollEvents();
        }

        accumulator.AddTime(Time.deltaTime, accumulator.TimeScale / TickRate);

        if (accumulator.Ticks > 0) {
            while (accumulator.ConsumeTick(out bool lastTick)) {

                _approximatedTime = _lastServerTime + (_currentLocalTime - _lastLocalTime) + _lastDelay;
                _targetTick = (int)(_approximatedTime / DeltaTime);

                var tickDifference = _tick - _targetTick;
                if (tickDifference > 0) {
                    accumulator.TimeScale = 1.05;
                }

                if (tickDifference == 0) {
                    accumulator.TimeScale = 1.0;
                }

                if (tickDifference < 0) {
                    accumulator.TimeScale = 0.95;
                }

                if ((_approximatedTime - _lastServerTime) > MaxPredictedTime) {
                    Debug.Log($"Ticks stalled {_tick}");
                } 
                else 
                {
                    if (tickDifference < -MaxTicksBehind) {
                        _tick = _targetTick;
                        Debug.Log($"Tick reset were {_tick} now {_targetTick}");
                    } 
                    else 
                    {
                        if (tickDifference > MaxTicksBehind) {
                            Debug.LogError($"Ticks stalled error {_tick}");
                            return;
                        }

                        _tick++;
                    }
                }

                SendInput timeSyncL;
                timeSyncL.LocalTime = _currentLocalTime;

                _Processor.SendNetSerializable(_Manager, ref timeSyncL, DeliveryMethod.Unreliable);
            }
        }
    }

    void RegisterMessages() {
        _Processor.SubscribeNetSerializable<Snapshot>((snapshot) => {
            if (_lastServerTime < snapshot.ServerTime) {
                _lastDelay = (_currentLocalTime - snapshot.ClientTime) / 2;
                _lastServerTime = snapshot.ServerTime;
                _lastLocalTime = _currentLocalTime;
            }

        });
    }

    private float _currentLocalTime;
    private float _lastServerTime;
    private float _lastLocalTime;
    private float _approximatedTime;
    private float _lastDelay;
    private int _tick;
    private int _targetTick;

    private void OnGUI() {
        GUI.color = Color.green;
        GUILayout.Label($"CLIENT_TIME {_currentLocalTime:F3}");
        GUILayout.Label($"SNAPSHOT_TIME {_lastServerTime:F3}");
        GUILayout.Label($"SIMULATION_TIME {_approximatedTime:F3}");
        GUILayout.Label($"DELTA_DELAY {_lastDelay:F3}");
        GUILayout.Label($"DELTA_TIME {accumulator.TimeScale / TickRate:F6}");
        GUILayout.Label($"LOCAL_TICK {_tick}");
        GUILayout.Label($"TARGET_TICK {_targetTick}");
        GUILayout.Label($"TIMESCALE {accumulator.TimeScale:F2}");
    }


    private void OnDestroy() {
        accumulator.Stop();
        _Manager.Stop();
        _Manager = null;
        Peer = null; 
    }
}
