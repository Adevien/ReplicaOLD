using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HexPlayer : MonoBehaviour
{
    public Rigidbody rb;

    public void Move(Inputs input) {
        Vector3 direction = default;

        if (input.IsDown(Inputs.BTN_FORWARD)) direction += transform.forward;
        if (input.IsDown(Inputs.BTN_BACKWARD)) direction -= transform.forward;
        if (input.IsDown(Inputs.BTN_LEFTWARD)) direction -= transform.right;
        if (input.IsDown(Inputs.BTN_RIGHTWARD)) direction += transform.right;

        rb.velocity += direction.normalized * 3f;
    }
}
