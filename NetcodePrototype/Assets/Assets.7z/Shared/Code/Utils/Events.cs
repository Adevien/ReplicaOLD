﻿public interface IInputEvent {
    public void OnInput<T>(ref T input);
}