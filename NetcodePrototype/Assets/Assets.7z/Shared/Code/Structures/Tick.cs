﻿using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit)]
public struct Tick {
    public sealed class EqualityComparer : IEqualityComparer<Tick> {
        public bool Equals(Tick x, Tick y) {
            return x._tick == y._tick;
        }

        public int GetHashCode(Tick obj) {
            return obj._tick;
        }
    }

    public const int SIZE = 4;
    public const int ALIGNMENT = 4;

    [FieldOffset(0)]
    int _tick;

    public Tick Next() {
        Tick t;
        t._tick = _tick + 1;
        return t;
    }

    public bool Equals(Tick other) {
        return _tick == other._tick;
    }

    public override bool Equals(object obj) {
        return obj is Tick other && Equals(other);
    }

    public override int GetHashCode() {
        return _tick;
    }

    public override string ToString() {
        return $"[Tick:{(int)this}]";
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static bool operator ==(Tick a, Tick b) {
        return a._tick == b._tick;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static bool operator !=(Tick a, Tick b) {
        return a._tick != b._tick;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static implicit operator Tick(int value) {
        Tick t;
        t._tick = value;
        return t;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static implicit operator int(Tick value) {
        return value._tick;
    }
}