﻿using System.Collections.Generic;
using UnityEngine;

public class HexNetRunner : MonoBehaviour {

    public static HexNetRunner Instance;

    private void Awake() {
        Instance = this;
    }

    public RefField<IInputEvent> OnInput;

    static List<HexBehaviour> _simulationBehaviours = new List<HexBehaviour>();

    public const int StepRate = 32;

    public const float StepTime = 1.0f / StepRate;

    double _stepAccumulator = 0.0;

    public static float Delta { get; private set; }

    public static void Subscribe(HexBehaviour sim) => _simulationBehaviours.Add(sim);

    public static void Unsubscribe(HexBehaviour sim) => _simulationBehaviours.Remove(sim);

    int Debug = 0;

    private void Update() {
        OnInput?.Value?.OnInput(ref Debug);

        foreach (HexBehaviour behaviour in _simulationBehaviours)
            behaviour.OnPreUpdate();

        _stepAccumulator += Time.deltaTime;

        while (_stepAccumulator >= StepTime) {
            _stepAccumulator -= StepTime;

            foreach (HexBehaviour behaviour in _simulationBehaviours)
                behaviour.OnFixedStep();
        }

        Delta = Mathf.Clamp01((float)(_stepAccumulator / StepTime));

        foreach (HexBehaviour behaviour in _simulationBehaviours)
            behaviour.Render();
    }
}