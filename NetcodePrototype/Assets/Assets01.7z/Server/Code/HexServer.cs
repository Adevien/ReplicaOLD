using LiteNetLib;
using LiteNetLib.Utils;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class HexServer : MonoBehaviour {
    NetPacketProcessor _Processor = new NetPacketProcessor();

    EventBasedNetListener _Events = new EventBasedNetListener();

    NetManager _Manager;

    public List<Player> Players = new List<Player>();

    public float Delta = 0.03125f;

    StepRunner _StepRunner;

    private void Awake() {
        _StepRunner = new StepRunner();
        _Manager = new NetManager(_Events);

        InitEvents();
        RegisterMessages();

        if (_Manager.Start(2500)) {
            print("HEX_SERVER: Started on port (2500).");
        } else print("HEX_SERVER: Failed to start manager.");

        _StepRunner.OnFixedUpdate += _StepRunner_OnFixedUpdate;
        _StepRunner.OnPreUpdate += _StepRunner_OnPreUpdate;
        _StepRunner.StepTime = Delta;

        _offsetTime = Time.time;

        accumulator = new TickAccumulator();
    }

    public int Ticks = 0;
    public double Times = 0;

    public TickAccumulator accumulator;

    public void Update() {
        _StepRunner.Step();

        accumulator.AddTime(Time.deltaTime, _StepRunner.StepTime);
        Ticks = accumulator.Ticks;
        Times = accumulator.Time;

        bool firstTick = false;
        if (accumulator.Ticks > 0) {
            while (accumulator.ConsumeTick(out bool lastTick)) {

                firstTick = false;
            }
        }
    }

    private void _StepRunner_OnPreUpdate() {
        _currentLocalTime = Time.time - _offsetTime;
    }

    private void _StepRunner_OnFixedUpdate() {
        if (_Manager.IsRunning) {
            _Manager.PollEvents();

            //_currentLocalTime = Time.time - _offsetTime;

            //var neededFrame = (int)(_currentLocalTime / Delta);

            //if (neededFrame > _tick && _Manager.IsRunning) {
            //    _tick++;
            //} else if(neededFrame < _tick) {
            //    Debug.LogError("Skipped frame");
            //}


            _tick++;

            TimeSync sync;
            sync.ReturnedLocalTime = LocalTimeRemote1;
            sync.ServerTime = _currentLocalTime;

            foreach (var peer in _Manager.ConnectedPeerList) {
                _Processor.SendNetSerializable(peer, ref sync, DeliveryMethod.Unreliable);
            }

        }
    }

    public float LocalTimeRemote1;

    void RegisterMessages() {
        _Processor.SubscribeNetSerializable<TimeSyncLocal, NetPeer>((timeSync, peer) => {

            LocalTimeRemote1 = timeSync.LocalTime;
        });
    }

    void InitEvents() {
        _Events.PeerConnectedEvent += OnPeerConnected;
        _Events.PeerDisconnectedEvent += OnPeerDisconnected;
        _Events.ConnectionRequestEvent += OnConnectionRequest;
        _Events.NetworkReceiveEvent += (peer, reader, channel, deliveryMethod) => _Processor.ReadAllPackets(reader, peer);
    }

    void OnConnectionRequest(ConnectionRequest request) {
        request.AcceptIfKey("hex_arena");
    }

    void OnPeerConnected(NetPeer peer) {
        if (Players.Any(x => x.Peer.EndPoint == peer.EndPoint)) return;
        Players.Add(new Player() { Peer = peer, /*SimulatedPlayer = Instantiate(PlayerPrefab, transform)*/ });

        print($"Player {peer.EndPoint} connected");
    }

    void OnPeerDisconnected(NetPeer peer, DisconnectInfo disconnectInfo) {
        if (Players.Any(x => x.Peer.EndPoint != peer.EndPoint)) return;
        var player = Players.Where(x => x.Peer.EndPoint == peer.EndPoint).FirstOrDefault();

        //notify all players that this one disconnected

        Destroy(player.SimulatedPlayer);
        Players.Remove(player);

        print($"Player {peer.EndPoint} disconnected. Reason {disconnectInfo.Reason}");
    }


    private float _offsetTime;
    private float _currentLocalTime;
    private ushort _tick;


    private void OnGUI() {

    }

    private void OnDestroy() {
        _Manager.Stop();
        _Manager = null;
    }
}
