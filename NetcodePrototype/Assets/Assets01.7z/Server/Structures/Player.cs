﻿using LiteNetLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

public class Player {
    public NetPeer Peer;
    public GameObject SimulatedPlayer;
    public Queue<InputCmd> InputBuffer = new Queue<InputCmd>();
}

