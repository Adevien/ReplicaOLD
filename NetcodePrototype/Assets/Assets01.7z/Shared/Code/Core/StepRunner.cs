﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

    public class StepRunner {

        public const int StepRate = 32;

        public float StepTime = 1.0f / StepRate;

        double _stepAccumulator = 0.0;

        public static float Delta { get; private set; }

        public delegate void CallbackStep();

        public CallbackStep OnPreUpdate;

        public CallbackStep OnFixedUpdate;

        public CallbackStep OnRender;

        public void Step() {

            OnPreUpdate?.Invoke();

              _stepAccumulator += Time.deltaTime;

            while (_stepAccumulator >= StepTime) {
                _stepAccumulator -= StepTime;

              OnFixedUpdate?.Invoke();
            }

            Delta = Mathf.Clamp01((float)(_stepAccumulator / StepTime));
            
            OnRender?.Invoke();
        }
    }
