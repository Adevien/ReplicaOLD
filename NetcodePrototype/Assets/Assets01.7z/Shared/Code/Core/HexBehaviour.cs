﻿using UnityEngine;

public abstract class HexBehaviour : MonoBehaviour {
    private void OnEnable() => HexNetRunner.Subscribe(this);

    private void OnDisable() => HexNetRunner.Unsubscribe(this);

    public virtual void OnPreUpdate() { }

    public virtual void OnFixedStep() { }

    public virtual void Render() { }
}