﻿using LiteNetLib.Utils;

public struct Inputs : INetSerializable {
    ushort buttons;

    public Inputs(ushort value) : this() => buttons = value;

    public bool IsUp(ushort button) => IsDown(button) == false;

    public bool IsDown(ushort button) => (buttons & button) == button;

    public void Serialize(NetDataWriter writer) {
        writer.Put(buttons);
    }

    public void Deserialize(NetDataReader reader) {
        buttons = reader.GetUShort();
    }

    public static implicit operator Inputs(ushort value) => new Inputs(value);

    public const byte BTN_FORWARD = 1 << 1;
    public const byte BTN_BACKWARD = 1 << 2;
    public const byte BTN_LEFTWARD = 1 << 3;
    public const byte BTN_RIGHTWARD = 1 << 4;
}

