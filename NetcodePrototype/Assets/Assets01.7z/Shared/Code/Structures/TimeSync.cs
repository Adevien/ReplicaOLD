﻿using LiteNetLib.Utils;

public struct TimeSync : INetSerializable {
    public float ReturnedLocalTime;
    public float ServerTime;

    public void Serialize(NetDataWriter writer) {
        writer.Put(ReturnedLocalTime);
        writer.Put(ServerTime);

    }

    public void Deserialize(NetDataReader reader) {
        ReturnedLocalTime = reader.GetFloat();
        ServerTime = reader.GetFloat();
    }
}

public struct TimeSyncLocal : INetSerializable {
    public float LocalTime;

    public void Serialize(NetDataWriter writer) {
        writer.Put(LocalTime);

    }

    public void Deserialize(NetDataReader reader) {
        LocalTime = reader.GetFloat();
    }
}
