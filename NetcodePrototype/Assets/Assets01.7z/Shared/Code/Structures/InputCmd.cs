﻿using LiteNetLib.Utils;
using System.Collections.Generic;

public struct InputCmd : INetSerializable {
    public float DeliveryTime;
    public int LastAckedTick;
    public int Length;
    public List<Inputs> Inputs;

    public void Deserialize(NetDataReader reader) {

        DeliveryTime = reader.GetFloat();
        LastAckedTick = reader.GetInt();
        Length = reader.GetInt();
        Inputs = new List<Inputs>();
        for (int i = 0; i < Length; i++) {
            Inputs.Add(reader.GetUShort());
        }
    }

    public void Serialize(NetDataWriter writer) {
       writer.Put(DeliveryTime);
       writer.Put(LastAckedTick);
       writer.Put(Inputs.Count);

        foreach (var input in Inputs) {
            input.Serialize(writer);
        }
    }
}