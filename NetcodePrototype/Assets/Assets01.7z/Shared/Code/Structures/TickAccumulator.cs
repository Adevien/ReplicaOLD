﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine.Assertions;

[Serializable]
public struct TickAccumulator {
    double _time;
    int _ticks;

    public int Ticks => _ticks;

    public double Time => _time;

    public bool AddTime(double dt, double step) {
        _time += dt;

        while (_time >= step) {
            _time -= step;
            _ticks += 1;
        }

        return _ticks > 0;
    }

    public bool ConsumeTick(out bool last) {
        if (_ticks > 0) {
            _ticks -= 1;
            last = _ticks == 0;
            return true;
        }

        last = false;
        return false;
    }
}