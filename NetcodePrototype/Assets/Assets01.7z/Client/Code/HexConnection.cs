using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LiteNetLib;
using LiteNetLib.Utils;
using UnityEngine.SceneManagement;

public class HexConnection : MonoBehaviour {

    NetPacketProcessor _Processor = new NetPacketProcessor();

    EventBasedNetListener _Events = new EventBasedNetListener();

    NetPeer Peer;

    NetManager _Manager;

    StepRunner _StepRunner;
    private void Awake() {
        _StepRunner = new StepRunner();
        _Manager = new NetManager(_Events);

        InitEvents();
        RegisterMessages();

        if (_Manager.Start()) {
            Peer = _Manager.Connect("127.0.0.1", 2500, "hex_arena");
            print("HEX_CONNECTION: Started on port (2500).");
        } else print("HEX_CONNECTION: Failed to start manager.");


        _StepRunner.OnPreUpdate += OnPreUpdate;
        _StepRunner.OnFixedUpdate += OnFixedUpdate;

        _StepRunner.StepTime = NormalDelta;
        _offsetTime = Time.time;
    }

    private void Update() {
        _StepRunner.Step();
    }

    void RegisterMessages() {
        _Processor.SubscribeNetSerializable<TimeSync>((timeSync) => {

            if (_lastReceivedTime < timeSync.ServerTime) {
                _lastDelay = (_currentLocalTime - timeSync.ReturnedLocalTime) / 2;
                _lastReceivedTime = timeSync.ServerTime;
                _localTimeAtLastReceivedTime = _currentLocalTime;
            }

        });

    }

    void InitEvents() {
        _Events.PeerConnectedEvent += OnPeerConnected;
        _Events.PeerDisconnectedEvent += OnPeerDisconnected;
        _Events.NetworkReceiveEvent += (peer, reader, channel, deliveryMethod) => _Processor.ReadAllPackets(reader);
    }

    void OnPeerConnected(NetPeer peer) {
        print($"We connected to server {peer.EndPoint}");
    }

    void OnPeerDisconnected(NetPeer peer, DisconnectInfo disconnectInfo) {
        print($"We disconnected from server {peer.EndPoint}. Reason {disconnectInfo.Reason}");
    }

    public int MaxTicksBehind = 8;
    public float MaxPredictedTime = 1f;
    public float NormalDelta = 0.03125f;
    public float LowerDelta = 0.03846154f;
    public float HigherDelta = 0.02631579f;

    private float _nextTimeUpdate;
    private float _offsetTime;
    private float _currentDelta;
    private float _currentLocalTime;
    private float _lastReceivedTime;
    private float _localTimeAtLastReceivedTime;
    private float _approximatedTime;
    private float _lastDelay;
    private float _timeChange;
    private int _tick;
    private int _targetTick;

    private void OnGUI() {
        GUILayout.Label($"LastReceivedTime {_lastReceivedTime:F3}");
        GUILayout.Label($"LocalAtLastReceivedTime {_localTimeAtLastReceivedTime:F3}");
        GUILayout.Label($"ApproximatedTime {_approximatedTime:F3}");
        GUILayout.Label($"Delay {_lastDelay:F3}");
        GUILayout.Label($"TimeChange {_timeChange:F3}");
        GUILayout.Label($"Delta {_currentDelta:F3}");
        GUILayout.Label($"Tick {_tick}");
        GUILayout.Label($"TargetTick {_targetTick}");
    }

    public void OnPreUpdate() {
        _currentLocalTime = Time.time - _offsetTime;

        var lastApproximatedTime = _approximatedTime;
        _approximatedTime = _lastReceivedTime + (_currentLocalTime - _localTimeAtLastReceivedTime) + _lastDelay;
        _targetTick = (int)(_approximatedTime / NormalDelta);

        _timeChange = _approximatedTime - lastApproximatedTime;

        var tickDifference = _tick - _targetTick;
        if (tickDifference > 0) {
            _StepRunner.StepTime = LowerDelta;
            _currentDelta = LowerDelta;
        }

        if (tickDifference == 0) {
            _StepRunner.StepTime = NormalDelta;
            _currentDelta = NormalDelta;
        }

        if (tickDifference < 0) {
            _StepRunner.StepTime = HigherDelta;
            _currentDelta = HigherDelta;
        }
    }

    public void OnFixedUpdate() {
        if (_Manager.IsRunning) {
            _Manager.PollEvents();

            //_currentLocalTime = Time.time - _offsetTime;
            //_approximatedTime = _lastReceivedTime + (_currentLocalTime - _localTimeAtLastReceivedTime) + _lastDelay;
            //_targetTick = (int)(_approximatedTime / NormalDelta);

            if (_approximatedTime - _lastReceivedTime > MaxPredictedTime) {
                Debug.Log($"Ticks stalled {_tick}");
            } else {
                var tickDifference = _tick - _targetTick;

                if (tickDifference < -MaxTicksBehind) {
                    Debug.Log($"Tick reset were {_tick} now {_targetTick}");
                    _tick = _targetTick;
                } else {
                    if (tickDifference > MaxTicksBehind) {
                        //Shouldn't happen ever 
                        Debug.LogError($"Ticks stalled {_tick} NEVER SHOULD HAPPEN");
                    } else {
                        _tick++;
                    }
                }
            }

            //if (_nextTimeUpdate < _currentLocalTime) {
            //    _nextTimeUpdate = _currentLocalTime;

                TimeSyncLocal timeSyncL;
                timeSyncL.LocalTime = _currentLocalTime;

                _Processor.SendNetSerializable(_Manager, ref timeSyncL, DeliveryMethod.Unreliable);
           // }
        }
    }

    private void OnDestroy() {
        _Manager.Stop();
        _Manager = null;
        Peer = null;
    }
}
