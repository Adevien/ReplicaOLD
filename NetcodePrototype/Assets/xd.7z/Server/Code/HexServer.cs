using LiteNetLib;
using LiteNetLib.Utils;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class HexServer : MonoBehaviour {
    NetPacketProcessor _Processor = new NetPacketProcessor();

    EventBasedNetListener _Events = new EventBasedNetListener();

    List<Player> _Players = new List<Player>();

    NetManager _Manager;

    private void Awake() {
        _Manager = new NetManager(_Events);

        _Events.PeerConnectedEvent += (peer) => {
            Debug.Log($"Peer {peer.EndPoint} connected");
            if(!_Players.Any(x => x.Peer.EndPoint == peer.EndPoint)) {
                _Players.Add(new Player() { Peer = peer });
            }
        };

        _Events.PeerDisconnectedEvent += (peer, di) => {
            print($"Peer {peer.EndPoint} disconnected. Reason {di.Reason}");
            _Players.Remove(_Players.First(x => x.Peer.EndPoint == peer.EndPoint));
        };

        _Events.ConnectionRequestEvent += (request) => request.AcceptIfKey("hex_arena");
        _Events.NetworkReceiveEvent += (peer, reader, channel, deliveryMethod) => _Processor.ReadAllPackets(reader, peer);

        RegisterMessages();

        Debug.Log($"HEX_SERVER: NetManager status: {(_Manager.Start(2500) ? "RUNNING" : "FAILED")}");

        accumulator = TickAccumulator.Initialize();
    }

    public TickAccumulator accumulator;

    public int TickRate = 32;

    public float DeltaTime {
        get => 1.0f / TickRate;
    }

    public int ServerTick;

    public float _currentLocalTime;

    public void Update() {

        _currentLocalTime = Time.time;

        if (_Manager.IsRunning) {
            _Manager.PollEvents();
        }

        accumulator.AddTime(Time.deltaTime, (double)DeltaTime);

        if (accumulator.Ticks > 0) {
            while (accumulator.ConsumeTick(out bool lastTick)) {

                ServerTick++;

                Snapshot snapshot;

                foreach (var player in _Players) {

                    //server OS time when it runs tick N -server OS time when it receives input for tick N = the delta you want to measure

                    snapshot.BufferingDelay = (_currentLocalTime - player.ReceivedTime);

                    _Processor.SendNetSerializable(player.Peer, ref snapshot, DeliveryMethod.Unreliable);
                }
            }
        }
    }

    void RegisterMessages() {
        _Processor.SubscribeNetSerializable<SendInput, NetPeer>((ts, peer) => {

            var player = _Players.First(x => x.Peer.EndPoint == peer.EndPoint);
            player.InputTime = ts.LocalTime;
            player.ReceivedTime = _currentLocalTime;
        });
    }


    private void OnDestroy() {
        accumulator.Stop();
        _Manager.Stop();
        _Manager = null;
    }
}
