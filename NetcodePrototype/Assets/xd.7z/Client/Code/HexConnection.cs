using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LiteNetLib;
using LiteNetLib.Utils;
using UnityEngine.SceneManagement;

public class HexConnection : MonoBehaviour {

    NetPacketProcessor _Processor = new NetPacketProcessor();

    EventBasedNetListener _Events = new EventBasedNetListener();

    NetPeer Peer;

    NetManager _Manager;

    private void Awake() {
        _Manager = new NetManager(_Events);

        _Events.PeerConnectedEvent += (peer) => Debug.Log($"We connected to server {peer.EndPoint}");
        _Events.PeerDisconnectedEvent += (peer, di) => Debug.Log($"We disconnected from server {peer.EndPoint}. Reason {di.Reason}");
        _Events.NetworkReceiveEvent += (peer, reader, channel, deliveryMethod) => _Processor.ReadAllPackets(reader);

        RegisterMessages();

        if (_Manager.Start()) {
            Peer = _Manager.Connect("127.0.0.1", 2500, "hex_arena");
            print("HEX_CONNECTION: Started on port (2500).");
        } else print("HEX_CONNECTION: Failed to start manager.");
        accumulator = TickAccumulator.Initialize();

        _delayAvg.Initialize(TickRate);
    }

    public TickAccumulator accumulator;

    public int TickRate = 32;

    public float DeltaTime {
        get => 1.0f / TickRate;
    }

    private float _currentLocalTime;

    public void Update() {

        _currentLocalTime = Time.time;

        if (_Manager.IsRunning) {
            _Manager.PollEvents();
        }

        accumulator.AddTime(Time.deltaTime, accumulator.TimeScale / TickRate);

        if (accumulator.Ticks > 0) {
            while (accumulator.ConsumeTick(out bool lastTick)) {

                var targetDelay = 2.0 * _delayAvg.Value;
                var actualDelay = _delayAvg.Value;

                diff = targetDelay - actualDelay;

                if (diff > 0.0078125) {
                    // not early enough
                    accumulator.TimeScale = 1.05f;
                } else if (diff < -0.0078125) {
                    // too early
                    accumulator.TimeScale = 0.95f;
                } else {
                    accumulator.TimeScale = 1.00f;
                }

                TimeScale = accumulator.TimeScale;

                ClientTick++;

                SendInput _sI;
                _sI.LocalTime = _currentLocalTime;

                _Processor.SendNetSerializable(_Manager, ref _sI, DeliveryMethod.Unreliable);
            }
        }
    }

    public double TimeScale;

    public double diff;

    public int ClientTick;

    StdDev _delayAvg;

    void RegisterMessages() {
        _Processor.SubscribeNetSerializable<Snapshot>((snapshot) => {
            _delayAvg.Integrate(snapshot.BufferingDelay);
            Debug.Log(_delayAvg.Value);
        });
    }


    private void OnDestroy() {
        accumulator.Stop();
        _Manager.Stop();
        _Manager = null;
        Peer = null; 
    }
}
