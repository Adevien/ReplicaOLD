﻿using LiteNetLib.Utils;

public struct SendInput : INetSerializable {
    public float LocalTime;

    public void Serialize(NetDataWriter writer) {
        writer.Put(LocalTime);

    }

    public void Deserialize(NetDataReader reader) {
        LocalTime = reader.GetFloat();
    }
}
